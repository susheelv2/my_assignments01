import logo from './logo.svg';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import React from 'react';
import Routes from './Routes';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Nav, Navbar  } from 'react-bootstrap';

const App = () => {
   

  return (
    <>
    <style type="text/css">
        {`
    .bg-primary {
         background-color: #e7f5fc !important;
    }
    .bd-example {
      padding: 1.5rem;
      margin: 10px 0px;
      text-align: left;
      position: relative;
      border: 2px solid #f8f9fa;
      }
    `}
      </style>

    <div className="App">
      <Navbar className="bg-body-tertiary justify-content-between">
        <Container>
          <Navbar.Brand href="/">
            <img src="https://www.espire.com/-/media/feature/identity/espire-logo.png?h=76&iar=0&w=101&hash=F4446C4DD92999F4DCBEF54F09AF7F47" />
            </Navbar.Brand>
          <Nav className="me-auto">
            <Link className="nav-link" to="/">Home</Link>
            <Link className="nav-link" to="/about">About</Link>
            <Link className="nav-link" to="/contact">Contact</Link>
            <Link className="nav-link" to="/login">Users</Link>
          </Nav>
        </Container>
      </Navbar>
      <Container>
      <Row>
      <div className="col-lg-12">
        <Routes /> 
      
      </div>
    </Row>
    </Container>
    </div> 
    </>   
  );
}

export default App;
