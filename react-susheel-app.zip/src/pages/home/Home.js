import React, {useState} from "react";

function Home(){
    const [count, setCount] = useState(0);

    return(
        <div>
            <h2>Home Page</h2>
            <p>Change the way we live by driving engaging experiences across enterprise with agile & scalable digital solutions!</p>
            <button className="btn btn-primary" onClick={() => setCount(count + 1)}>Click <i className="hide">{count}</i></button>
        </div>
    )
}

export default Home;