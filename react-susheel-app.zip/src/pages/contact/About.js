import React, {useEffect,useState} from "react";
import axios from 'axios';

function About(){
    const [colr, setColor] = useState('yellow');
    const [data, setData] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredData, setFilteredData] = useState([]);

    useEffect(() => {
        document.title = `You clicked ${colr}`;        
    }, [colr]);

    const searchFunction = (event) => {
        const query = event.target.value;
        setSearchQuery(query);
    
        const filtered = data?.filter(item =>
        item.title.toLowerCase().includes(query.toLowerCase()) ||
        item.body.toLowerCase().includes(query.toLowerCase())
        );
        setFilteredData(filtered); 
    };
 
    return(
        <div className="container">
            
            <p id="clickId" style={{ backgroundColor: colr }}>Color is {colr}</p>
            <button className="btn btn-primary" onClick={() => setColor(colr === 'red'?'yellow':'red')}>Change Color</button>
            <h1>About</h1>
            <div class="pull-left">
            <p>We are a Digital Transformation and Total Experience (TX) Solutions provider with a Cross-Enterprise approach to deliver future-ready services that are resilient to market disruptions.<br />
With focus on TX, we are paving way for enterprises to deploy &amp; deliver the best Customer Experience (CX), Employee Experience (EX), and Business Experience (BX) – with overarching service offerings around Multi-Experience (MX), and User Experience (UX). <br />

We are a CMMI Level 5 appraised organisation ensuring the highest standards of quality to deliver unparalleled service experience to all our customers worldwide. </p>
            </div>
        </div>
    )
}

export default About;