import React, {useEffect,useState} from "react";
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import LoginComponent from '../../components/Login/LoginComponent';

const FormLogin = () => {

  const [filteredData, setFilteredData] = useState([]);
  const apiUrl = process.env.REACT_APP_API_URL;

  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [errors, setErrors] = useState({});

  const fetchData = async () => {
      try {
        const response =  await axios.get(apiUrl+'api/users?name='+formData.username);
        //setData(response.data);
      // console.log(response.data);
        //setFilteredData(response.data); 
        const users = response.data;
        const query = formData.username;
        const filtered = users?.filter(item =>
          item.userName.toLowerCase().includes(query.toLowerCase())
          );
          setFilteredData(filtered); 
    } catch (error) {
        console.error('Error fetching data:', error);
    }
  }

  const formValidate = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const formSubmit = (e) => {
    e.preventDefault();
    const errors = validateFormData(formData);
    console.log(errors);
    if (Object.keys(errors).length === 0) {
      // Form submission logic here
      console.log('Form submitted successfully!');
      
      fetchData();
      } else {
      setErrors(errors);
    }
  };

  const validateFormData = (data) => {
    const errors = {};

    // Username validation
    if (!data.username.trim()) {
      errors.username = 'Username is required';
    } else if (!/^[a-zA-Z0-9]+$/.test(data.username)) {
      errors.username = 'Username should contain only letters and numbers';
    } else if (/[^a-zA-Z0-9]/.test(data.username)) {
      errors.username = 'Username should not contain special characters';
    }  

    return errors;
  };

  useEffect(() => {
    fetchData();      
});

  return (
    <div className="container"> 
      <div className="bd-example">
       <Form onSubmit={formSubmit}> 
      <div className="modal-dialog" role="document">
        <div className="modal-content">
        <div className="modal-header">  
          <h2>Search Users form Node Service</h2>
        </div> 
        <div className="modal-body">         
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <Form.Label>Search by Username</Form.Label>
            <Form.Control type="text" 
              name="username" 
              value={formData.username} 
              placeholder="Enter username"  
              onChange={formValidate} 
            />
           
            {errors.username && <p className="error">{errors.username}</p>}
          </Form.Group>         
        </div>
        <div className="modal-footer">
          <Button variant="primary" type="submit">
            Search
          </Button>
        </div>
        </div>
        </div>
      </Form> 
      </div> 
      <LoginComponent filteredData={filteredData}/>   
    </div>
  );
};

export default FormLogin;
