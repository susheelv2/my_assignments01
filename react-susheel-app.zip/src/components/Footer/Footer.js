import React from 'react';
import './Footer.css';

const Footer = () => {
    return (
        <footer className="footer">
            {/* Footer content */}
        </footer>
    );
};

export default Footer;
