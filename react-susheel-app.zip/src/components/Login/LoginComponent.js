// ChildComponent.js
import React,{useEffect,useState} from 'react';
const LoginComponent = ({filteredData}) => {
    
    return (
     <>
      <table className="table table-striped">
        <thead>
          <tr>
        <th><strong>UserName</strong></th> 
        <th><strong>Address</strong></th> 
        </tr>
        </thead>
        <tbody>
        {filteredData.map((item, index) => (
          <tr key={index}>
            <td>{item.userName} </td>
            <td> {item.userAddress}</td>
          </tr>
        ))}
        </tbody>
      </table>
     </>
  );
};

export default LoginComponent;
