// ChildComponent.js
import React,{useEffect,useState} from 'react';
const AboutComponent = ({filteredData}) => {
    
    return (
     <>
      <table className="table table-striped">
        <thead>
          <tr>
        <th><strong>Title</strong></th> 
        <th><strong>Body</strong></th> 
        </tr>
        </thead>
        <tbody>
        {filteredData.map((item, index) => (
          <tr key={index}>
            <td>{item.title} </td>
            <td> {item.body}</td>
          </tr>
        ))}
        </tbody>
      </table>
     </>
  );
};

export default AboutComponent;
