import React from "react";

const AboutSearch = ({searchQuery,searchFunction}) => {
   
    return (
     <>
     <div class="mb-3">
        <label class="form-label">Search</label>
       <input
       className="form-control"
        type="text"
        placeholder="Search..."
        value={searchQuery}
        onChange={searchFunction}
      />
      </div>
     </>
  );
};

export default AboutSearch;
