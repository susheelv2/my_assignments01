import React from 'react';
import './Middle.css';

const Middle = () => {
    return (
        <div className="middle">
            {/* Middle content */}
        </div>
    );
};

export default Middle;
