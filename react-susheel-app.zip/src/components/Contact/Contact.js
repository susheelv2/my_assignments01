// ChildComponent.js
import React,{useEffect,useState} from 'react';
const ContactComponent = ({filteredData}) => {
    
    return (
     <>
    <h2>Contact</h2>

    
     </>
  );
};

export default ContactComponent;
