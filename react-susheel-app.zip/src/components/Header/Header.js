import React from 'react';
import './Header.css';

const Header = () => {
    return (
        <header className="header">
            {/* Header content */}
        </header>
    );
};

export default Header;
