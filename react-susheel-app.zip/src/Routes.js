import React from "react";
import { Routes as Switch, Route, Navigate} from 'react-router-dom';

import Home from "./pages/home/Home";
import About from "./pages/contact/About";
import Contact from "./pages/contact/Contact";
import FormLogin from "./pages/login/FormLogin";

function Routes(){

    return(
        <div>
            <Switch>
                <Route path="/" element={<Home/>}></Route>
                <Route path="/about" element={<About/>}></Route>
                <Route path="/contact" element={<Contact/>}></Route>
                <Route path="/login" element={<FormLogin/>}></Route>
            </Switch>
        </div>
    )
}

export default Routes;