// server.js
const cors = require('cors');
const express = require('express');
const app = express();
const PORT = process.env.PORT || 5000;
app.use(cors());
app.options('*', cors());


// Sample user data
const Users = [
  { userId: 1, userName: 'John', userAddress: '123 Main St', userDescription: 'Lorem ipsum dolor sit amet' },
  { userId: 2, userName: 'Susheel', userAddress: '123 Hornsby St', userDescription: 'Lorem ipsum dolor sit amet' },
  { userId: 3, userName: 'Jane', userAddress: '456 Elm St', userDescription: 'Consectetur adipiscing elit' },
  { userId: 4, userName: 'Bharat Sethi', userAddress: 'Australias', userDescription: 'Lorem ipsum dolor sit amet' },
  { userId: 5, userName: 'Rita', userAddress: 'Delhi', userDescription: 'Consectetur adipiscing elit' }
];

// Endpoint to get all users
app.get('/api/users', (req, res) => {
	//console.log(req.query.name);
    //res.send('Response send to client::'+req.query.name);
	var filtered = [];
	if(req.query.name){
	   var nm = req.query.name;
	   console.log(nm);
	   filtered = Users?.filter(item =>
				  item.userName.toLowerCase().includes(nm.toLowerCase())
				  );
   }
   filtered = (filtered.length > 0)?filtered:Users;
  res.json(filtered);
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});